import useTheme, { ColorScheme } from "@/hooks/useTheme";
import { Link } from "expo-router";
import { useMemo } from "react";
import {
  Linking,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

type Social = {
  instagram?: string;
  linkedin?: string;
  github?: string;
};

const MEMBERS = [
  {
    name: "P Shaeshanth",
    id: "240616J",
    role: "Team Lead",
    social: {
      instagram: "https://instagram.com/shaeshanth2004",
      linkedin: "https://linkedin.com/in/shaeshanthprabaharan",
      github: "https://github.com/shaeshanth2004",
    },
  },
  {
    name: "Nethmie ND",
    id: "240142C",
    role: "Developer",
    social: {
      linkedin: "https://linkedin.com/in/nethmie-nd",
    },
  },
  {
    name: "MNF Shameera",
    id: "240617M",
    role: "Developer",
    social: {
      github: "https://github.com/shameera-mnf",
    },
  },
  {
    name: "Sesathviiyah R",
    id: "240612T",
    role: "Developer",
    social: {
      github: "https://github.com/sesathviiyahr",
    },
  },
  {
    name: "Kulunu T",
    id: "240618K",
    role: "Developer",
    social: {
      github: "https://github.com/kulunu-t",
    },
  }
];

const SOCIALS = [
  { key: "instagram", label: "Instagram", color: "#E4405F" },
  { key: "linkedin", label: "LinkedIn", color: "#0A66C2" },
  { key: "github", label: "GitHub", color: "#8B949E" },
];

export default function AboutScreen() {
  const { colors } = useTheme();
  const styles = useMemo(() => makeStyles(colors), [colors]);

  return (
    <SafeAreaView style={styles.root}>
      <ScrollView contentContainerStyle={styles.container}>
        {/* Hero */}
        <View style={styles.hero}>
          <Text style={styles.kicker}>ABOUT · ATOMIC FIVE</Text>

          <Text style={styles.title}>
            Flood Alerts, designed with clarity.
          </Text>

          <Text style={styles.text}>
            A modern university software project for flood awareness and
            object-oriented software development.
          </Text>

          <View style={styles.tags}>
            <Tag text="CS1040" styles={styles} />
            <Tag text="OOSD" styles={styles} />
            <Tag text="NSBM" styles={styles} />
          </View>
        </View>

        {/* Stats */}
        <View style={styles.stats}>
          <Stat title="TEAM" value="5 Members" styles={styles} />
          <Stat title="GROUP" value="Atomic Five" styles={styles} />
          <Stat title="YEAR" value="2025" styles={styles} />
          <Stat title="MODULE" value="CS1040" styles={styles} />
        </View>

        {/* Team */}
        <Text style={styles.section}>TEAM MEMBERS</Text>

        {MEMBERS.map((m) => (
          <View key={m.id} style={styles.card}>
            <Text style={styles.name}>{m.name}</Text>

            <Text style={styles.meta}>
              {m.id} · {m.role}
            </Text>

            <View style={styles.socials}>
              {SOCIALS.map((s) => {
                const link = m.social[s.key as keyof Social];

                if (!link) return null;

                return (
                  <Pressable
                    key={s.key}
                    onPress={() => Linking.openURL(link)}
                    style={[
                      styles.socialBtn,
                      { borderColor: s.color + "55" },
                    ]}
                  >
                    <Text style={[styles.socialText, { color: s.color }]}>
                      {s.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        ))}

        {/* Button */}
        <Link href="/" asChild>
          <Pressable style={styles.button}>
            <Text style={styles.buttonText}>BACK TO HOME</Text>
          </Pressable>
        </Link>

        <Text style={styles.footer}>
          © AtomicFive
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function Tag({
  text,
  styles,
}: {
  text: string;
  styles: ReturnType<typeof makeStyles>;
}) {
  return (
    <View style={styles.tag}>
      <Text style={styles.tagText}>{text}</Text>
    </View>
  );
}

function Stat({
  title,
  value,
  styles,
}: {
  title: string;
  value: string;
  styles: ReturnType<typeof makeStyles>;
}) {
  return (
    <View style={styles.stat}>
      <Text style={styles.statTitle}>{title}</Text>
      <Text style={styles.statValue}>{value}</Text>
    </View>
  );
}

function makeStyles(c: ColorScheme) {
  return StyleSheet.create({
    root: {
      flex: 1,
      backgroundColor: c.bg,
    },

    container: {
      padding: 20,
      paddingBottom: 40,
    },

    hero: {
      backgroundColor: c.surface,
      borderRadius: 24,
      padding: 22,
      borderWidth: 1,
      borderColor: c.border,
      marginBottom: 24,
    },

    kicker: {
      color: c.primary,
      fontSize: 11,
      fontFamily: "monospace",
      marginBottom: 12,
      letterSpacing: 2,
    },

    title: {
      fontSize: 34,
      fontWeight: "900",
      color: c.text,
      marginBottom: 12,
    },

    text: {
      color: c.textMuted,
      fontSize: 14,
      lineHeight: 22,
      marginBottom: 16,
    },

    tags: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 10,
    },

    tag: {
      paddingHorizontal: 12,
      paddingVertical: 8,
      borderRadius: 10,
      backgroundColor: c.bg,
      borderWidth: 1,
      borderColor: c.border,
    },

    tagText: {
      color: c.text,
      fontSize: 12,
      fontFamily: "monospace",
    },

    stats: {
      flexDirection: "row",
      flexWrap: "wrap",
      justifyContent: "space-between",
      marginBottom: 28,
    },

    stat: {
      width: "48%",
      backgroundColor: c.surface,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: c.border,
      padding: 16,
      marginBottom: 12,
    },

    statTitle: {
      color: c.textMuted,
      fontSize: 11,
      marginBottom: 6,
    },

    statValue: {
      color: c.text,
      fontSize: 18,
      fontWeight: "800",
    },

    section: {
      color: c.primary,
      fontSize: 12,
      letterSpacing: 2,
      marginBottom: 14,
      fontFamily: "monospace",
    },

    card: {
      backgroundColor: c.surface,
      borderRadius: 20,
      borderWidth: 1,
      borderColor: c.border,
      padding: 18,
      marginBottom: 14,
    },

    name: {
      fontSize: 16,
      fontWeight: "800",
      color: c.text,
      marginBottom: 5,
    },

    meta: {
      color: c.textMuted,
      marginBottom: 14,
      fontSize: 13,
    },

    socials: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 10,
    },

    socialBtn: {
      borderWidth: 1,
      borderRadius: 12,
      paddingHorizontal: 12,
      paddingVertical: 10,
    },

    socialText: {
      fontWeight: "700",
      fontSize: 12,
    },

    button: {
      marginTop: 16,
      backgroundColor: c.primary,
      paddingVertical: 15,
      borderRadius: 14,
      alignItems: "center",
    },

    buttonText: {
      color: "#fff",
      fontWeight: "800",
      letterSpacing: 1,
    },

    footer: {
      textAlign: "center",
      marginTop: 22,
      color: c.textMuted,
      fontSize: 10,
      fontFamily: "monospace",
    },
  });
}